//
//  ListPage.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit
import CoreData


extension String {
    var length: Int {
        return characters.count
    }
}

class ListPage: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView : UITableView?
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var data = NSMutableArray()
    var receivedData = NSMutableData()
    var filteredTableData:NSMutableArray?
    let delegate = UIApplication.sharedApplication().delegate as? AppDelegate
    
    
    
    //MARK: - View controller life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Places List"
        getDataFromDB()
        filter("")
    }
    
    func filter(fileterString:String){
        filteredTableData = NSMutableArray()
        let fetchRequest = NSFetchRequest()
        let entityDescription = NSEntityDescription.entityForName("Place", inManagedObjectContext:delegate!.managedObjectContext)

        fetchRequest.entity = entityDescription
        
        // Define how we want our entities to be sorted
       let sortDescriptor = NSSortDescriptor(key: "text", ascending: true)
       let sortDescriptors = [sortDescriptor]
       fetchRequest.sortDescriptors = sortDescriptors
        
        // If we are searching for anything...
        if( fileterString.length > 0)
        {
            // Define how we want our entities to be filtered
            let predicate = NSPredicate(format: "(name CONTAINS[c] %@) OR (details CONTAINS[c] %@)", argumentArray: [fileterString,fileterString])
            fetchRequest.predicate = predicate
        }
        
        do {
            let result = try delegate!.managedObjectContext.executeFetchRequest(fetchRequest)
            filteredTableData = NSMutableArray(array: result)
            
        } catch {
            let fetchError = error as NSError
            print(fetchError)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getDataFromDB(){
        // update core data
        let managedContext = delegate!.managedObjectContext
        
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest()
        
        // Create Entity Description
        let entityDescription = NSEntityDescription.entityForName("Place", inManagedObjectContext: managedContext)
        
        // Configure Fetch Request
        fetchRequest.entity = entityDescription
        
        do {
            let result = try managedContext.executeFetchRequest(fetchRequest)
            if result.count > 0 {
                filter("")
                updateUI()
            }else{
                fetchFromAPI()
                filter("")
            }
            
        } catch {
            let fetchError = error as NSError
            print(fetchError)
        }
    }
    
    func fetchFromAPI(){
        fetchAPIData()
    }

    //MARK: - Updation
    
    func updateUI()
    {
        tableView?.dataSource = self
        tableView?.delegate = self
        activityIndicator.hidden = true;
        tableView?.reloadData()
    }
    
    //MARK: - API
    
    func fetchAPIData()
    {
        
        let urlString = "http://tour-pedia.org/api/getReviews?location=London&category=attraction&language=fr"
        print("URL -> \(urlString)")
        
        let request = NSMutableURLRequest(URL: NSURL(string: urlString)!)
        request.HTTPMethod = Request.Method.GET
        request.timeoutInterval = Request.TIME_OUT_INTERVAL
        
        request.setValue(Request.ContentType.formEncoded, forHTTPHeaderField: Request.Headers.contentType)
        request.setValue(Request.ContentType.json, forHTTPHeaderField: Request.Headers.accept)
        
        activityIndicator.startAnimating();
        NSURLConnection(request: request, delegate: self)
        
    }
    
    //MARK: - NSURL Connection
    
    func connection(didReceiveResponse: NSURLConnection!, didReceiveResponse response: NSURLResponse!) {
        
        if let httpResponse = response as? NSHTTPURLResponse {
            let statusCode = httpResponse.statusCode
            print(statusCode)
        }
    }
    
    
    func connection(connection: NSURLConnection!, didReceiveData conData: NSData!) {
        
       receivedData.appendData(conData)
    }
    
    func connectionDidFinishLoading(connection: NSURLConnection!) {
        
        let jsonString = NSString(data: receivedData, encoding: NSUTF8StringEncoding)
        
        data = Utility.convertAnyObjectIntoJSON(jsonString!) as! NSMutableArray
        activityIndicator.stopAnimating();
        insertIntoDB(data)
        filter("")
        updateUI()
    }
    
    func insertIntoDB(data:NSMutableArray){
        let managedContext = delegate!.managedObjectContext
        
        for placeObject in data {
           let entity =  NSEntityDescription.entityForName("Place", inManagedObjectContext:managedContext)
            let place = NSManagedObject(entity: entity!, insertIntoManagedObjectContext: managedContext)
            let source = placeObject.valueForKey("source")
            let text = placeObject.valueForKey("text")
            let time = placeObject.valueForKey("time")
            let details = placeObject.valueForKey("details")
            
            place.setValue(source, forKey: "source")
            place.setValue(text, forKey: "text")
            place.setValue(time, forKey: "time")
            place.setValue(details, forKey: "detail")
        }
        
        do {
            try managedContext.save()
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    

    //MARK: - UITableview datasource and delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredTableData!.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! ListCell
        
       /* if let source = data[indexPath.row].valueForKey("source") {
           cell.titleLbl?.text = source as? String
        }
        
        if let text = data[indexPath.row].valueForKey("text") {
            cell.nameLbl?.text = text as? String
        }
        
        if let time = data[indexPath.row].valueForKey("time") {
            cell.describtionLbl?.text = time as? String
        }*/
        
        let place = filteredTableData?.objectAtIndex(indexPath.row) as? Place
        cell.titleLbl?.text = place!.source
        cell.nameLbl?.text = place!.text
        cell.describtionLbl?.text = place!.time
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyBoard.instantiateViewControllerWithIdentifier("viewPage") as! ViewPage
        let place = filteredTableData?.objectAtIndex(indexPath.row) as? Place
        view.objectData = place
        self.navigationController?.pushViewController(view, animated: true)
        
    }
    
}
