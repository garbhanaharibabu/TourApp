//
//  ListCell.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {

    
    @IBOutlet weak var titleLbl : UILabel?
    @IBOutlet weak var nameLbl : UILabel?
    @IBOutlet weak var describtionLbl : UILabel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
