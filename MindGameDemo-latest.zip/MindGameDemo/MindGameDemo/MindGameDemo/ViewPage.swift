//
//  ViewPage.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class ViewPage: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView : UITableView?
    
    var objectData : Place?
    
    var data : AnyObject?
    var receivedData = NSMutableData()
    
    //MARK: - View controller life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
        if let source = objectData?.source{
            self.title = source
        }
        
        
        configureView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Updation
    
    func updateUI()
    {
        tableView?.dataSource = self
        tableView?.delegate = self
        
        tableView?.reloadData()
    }
    
    //MARK: - API
    
    func configureView()
    {
        var urlString : String = ""
        
        if let details = objectData?.detail {
            urlString = details
        }
        
        print("URL -> \(urlString)")
        
        let request = NSMutableURLRequest(URL: NSURL(string: urlString)!)
        request.HTTPMethod = Request.Method.GET
        request.timeoutInterval = Request.TIME_OUT_INTERVAL
        
        request.setValue(Request.ContentType.formEncoded, forHTTPHeaderField: Request.Headers.contentType)
        request.setValue(Request.ContentType.json, forHTTPHeaderField: Request.Headers.accept)
        
        NSURLConnection(request: request, delegate: self)
        
    }
    
    //MARK: - NSURL Connection
    
    func connection(didReceiveResponse: NSURLConnection!, didReceiveResponse response: NSURLResponse!) {
        
        if let httpResponse = response as? NSHTTPURLResponse {
            let statusCode = httpResponse.statusCode
            print(statusCode)
        }
    }
    
    
    func connection(connection: NSURLConnection!, didReceiveData conData: NSData!) {
        
        receivedData.appendData(conData)
    }
    
    func connectionDidFinishLoading(connection: NSURLConnection!) {
        
        let jsonString = NSString(data: receivedData, encoding: NSUTF8StringEncoding)
        
        //print(jsonString)
        
        data = Utility.convertAnyObjectIntoJSON(jsonString!)
        
     //   print(data)
        
        updateUI()
    }
    
    
    
    
    //MARK: - UITableview datasource and delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! ViewCell
        
        
        cell.field1?.text = Utility.getStringValueByKey(data!, key: "polarity")
        cell.field2?.text = Utility.getStringValueByKey(data!, key: "rating")
        cell.field3?.text = Utility.getStringValueByKey(data!, key: "source")
        cell.field4?.text = Utility.getStringValueByKey(data!, key: "text")
        cell.field5?.text = Utility.getStringValueByKey(data!, key: "time")
        cell.field6?.text = Utility.getStringValueByKey(data!, key: "wordsCount")

        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
}

