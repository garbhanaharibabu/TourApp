//
//  Request.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class Request : NSObject
{
    
    /**
     Encapsulates the data required to send an HTTP request.
     */
     
     /// The `Method` defines the supported HTTP methods.
    struct Method {
        static let GET = "GET"
        static let HEAD = "HEAD"
        static let POST = "POST"
        static let PUT = "PUT"
        static let DELETE = "DELETE"
    }
    
    /// A group of static constants for referencing HTTP header field names.
    struct Headers {
        static let userAgent = "User-Agent"
        static let contentType = "Content-Type"
        static let contentLength = "Content-Length"
        static let accept = "Accept"
        static let cacheControl = "Cache-Control"
    }
    
    /// A group of static constants for referencing supported HTTP
    /// `Content-Type` header values.
    struct ContentType {
        static let formEncoded = "application/x-www-form-urlencoded"
        static let json = "application/json"
    }
    
    
    /// The URL string of the HTTP request.
    static var url: String = ""
    
    //Time out
    static let TIME_OUT_INTERVAL : NSTimeInterval = 60
    
    /**
     The parameters to encode in the HTTP request. Request parameters are percent
     encoded and are appended as a query string or set as the request body
     depending on the HTTP request method.
     */
    static var parameters = [String : AnyObject]()
    
}

