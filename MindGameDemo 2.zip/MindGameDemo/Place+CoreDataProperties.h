//
//  Place+CoreDataProperties.h
//  MindGameDemo
//
//  Created by Mani on 1/27/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Place.h"

NS_ASSUME_NONNULL_BEGIN

@interface Place (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *source;
@property (nullable, nonatomic, retain) NSString *text;
@property (nullable, nonatomic, retain) NSString *time;
@property (nullable, nonatomic, retain) NSString *detail;

@end

NS_ASSUME_NONNULL_END
