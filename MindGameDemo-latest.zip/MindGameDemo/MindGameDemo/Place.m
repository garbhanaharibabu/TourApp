//
//  Place.m
//  MindGameDemo
//
//  Created by Mani on 1/27/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

#import "Place.h"

@implementation Place

// Insert code here to add functionality to your managed object subclass

@end
