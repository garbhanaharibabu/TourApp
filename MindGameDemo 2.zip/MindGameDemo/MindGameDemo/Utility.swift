//
//  Utility.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class Utility: NSObject {
    
    static func convertAnyObjectIntoJSON(json : AnyObject) -> AnyObject
    {
        do {
            let data: NSData = json.dataUsingEncoding(NSUTF8StringEncoding)!
            let jsonData: AnyObject = try NSJSONSerialization.JSONObjectWithData(data, options:  NSJSONReadingOptions(rawValue: 0))
            
            return jsonData
        }
        catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }
        
        return NSMutableArray()
    }

    
    class func getStringValueByKey(item : AnyObject, key : String) -> String
    {
        if let copyValue: AnyObject = item.objectForKey(key) {
            return convertAnyObjectIntoString(copyValue)
        }
        else {
            return ""
        }
    }
    
    static func convertAnyObjectIntoString(value : AnyObject) -> String!
    {
        if let numberValue = value as? NSNumber {
            return numberValue.stringValue
        }
        else if let stringValue = value as? String {
            return stringValue
        }
        
        return value.stringValue
    }

    
    
}
