//
//  ViewController.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showListPage(sender : UIButton)
    {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let list = storyBoard.instantiateViewControllerWithIdentifier("listPage") as! ListPage
        self.navigationController?.pushViewController(list, animated: true)
    }


}

