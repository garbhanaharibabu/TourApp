//
//  ViewCell.swift
//  MindGameDemo
//
//  Created by Manikandan Sundararajan on 27/01/16.
//  Copyright © 2016 Manikandan Sundararajan. All rights reserved.
//

import UIKit

class ViewCell: UITableViewCell {
    
    @IBOutlet weak var field1 : UILabel?
    @IBOutlet weak var field2 : UILabel?
    @IBOutlet weak var field3 : UILabel?
    @IBOutlet weak var field4 : UILabel?
    @IBOutlet weak var field5 : UILabel?
    @IBOutlet weak var field6 : UILabel?


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
